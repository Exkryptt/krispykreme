'use client';

export default function ManagerDashboard() {
    return (
        <div style={{ padding: '2rem' }}>
            <h1>Manager Dashboard</h1>
            <p>Welcome to the manager's dashboard. You can manage products, orders, and other features here.</p>
        </div>
    );
}
