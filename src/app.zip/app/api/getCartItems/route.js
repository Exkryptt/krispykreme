import { getCustomSession } from '../../../../lib/sessionCode.js';

export async function GET(req) {
    const session = await getCustomSession();

    // Ensure cart is initialized
    if (!session.cart) {
        session.cart = [];
    }

    return new Response(JSON.stringify({ cart: session.cart }), { status: 200 });
}
