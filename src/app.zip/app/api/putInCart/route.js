import { getCustomSession } from '../../../../lib/sessionCode.js';
import connectToDatabase from '../../../../lib/mongodb';  // Correct default import

export async function POST(req) {
    const { productId, quantity } = await req.json();

    if (!productId || !quantity) {
        return new Response(
            JSON.stringify({ error: 'ProductId and quantity are required' }),
            { status: 400 }
        );
    }

    // Fetch the product data from the database
    const db = await connectToDatabase();
    const product = await db.collection('products').findOne({ _id: productId });

    if (!product) {
        return new Response(
            JSON.stringify({ error: 'Product not found' }),
            { status: 404 }
        );
    }

    const session = await getCustomSession();

    // Initialize cart if it doesn't exist
    if (!session.cart) {
        session.cart = [];
    }

    // Add or update product in the cart
    const existingProduct = session.cart.find(item => item.productId === productId);
    if (existingProduct) {
        existingProduct.quantity += quantity;
    } else {
        session.cart.push({
            productId,
            quantity,
            pname: product.pname,
            price: product.price,
        });
    }

    // Save session
    await session.save();

    return new Response(
        JSON.stringify({ message: 'Product added to cart', cart: session.cart }),
        { status: 200 }
    );
}
