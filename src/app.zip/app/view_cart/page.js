'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Button from '@mui/material/Button';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';

export default function ViewCartPage() {
    const [cart, setCart] = useState([]);
    const [total, setTotal] = useState(0);
    const router = useRouter();

    useEffect(() => {
        // Fetch cart items from the API
        fetch('/api/getCartItems')
            .then(res => res.json())
            .then(data => {
                setCart(data.cart);
                calculateTotal(data.cart);
            });
    }, []);

    const calculateTotal = (cart) => {
        const totalAmount = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
        setTotal(totalAmount);
    };

    const handleRemove = (productId) => {
        // Remove product from cart
        fetch('/api/removeFromCart', {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ productId }),
        })
            .then(res => res.json())
            .then(data => setCart(data.cart));
    };

    const handleCheckout = () => {
        // Redirect to checkout page
        router.push('/checkout');
    };

    return (
        <Box sx={{ padding: 3 }}>
            <Typography variant="h4">Your Cart</Typography>
            {cart.length === 0 ? (
                <Typography>No items in cart.</Typography>
            ) : (
                <>
                    {cart.map((item) => (
                        <Box key={item.productId} sx={{ marginBottom: 2, display: 'flex', justifyContent: 'space-between' }}>
                            <Typography>{item.pname} - {item.quantity} x ${item.price}</Typography>
                            <Button onClick={() => handleRemove(item.productId)}>Remove</Button>
                        </Box>
                    ))}
                    <Typography variant="h6">Total: ${total}</Typography>
                    <Button onClick={handleCheckout} variant="contained" sx={{ marginTop: 2 }}>Proceed to Checkout</Button>
                </>
            )}
        </Box>
    );
}
